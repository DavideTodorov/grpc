﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Car.Parking.System.Models
{
    public class CarModel
    {
        public CarModel(string name, int year, string color, double price)
        {
            Name = name;
            Parts = new List<Part>();
            Year = year;
            Color = color;
            Price = price;
        }

        [Key]
        public int Id { get; set; }

        public string Name { get; set; }
        public int Year { get; set; }
        public string Color { get; set; }
        public double Price { get; set; }

        public List<Part> Parts { get; set; }

        public override string ToString()
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendLine($"Id {Id}");
            stringBuilder.AppendLine($"Name {Name}");
            stringBuilder.AppendLine($"Year {Year}");
            stringBuilder.AppendLine($"Price {Price}");
            stringBuilder.AppendLine($"Color {Color}");
           
            return stringBuilder.ToString();
        }
    }
}
