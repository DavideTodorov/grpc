﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Car.Parking.System.Models
{
    public class ParkingModel
    {
        public ParkingModel(string name)
        {
            Name = name;
            Cars = new List<CarModel>();
        }

        [Key]
        public int Id { get; set; }

        public string Name { get; set; }

        public List<CarModel> Cars { get; set; }

        public override string ToString()
        {
            StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.AppendLine($"Id: {Id}");
            stringBuilder.AppendLine($"Name: {Name}");

            return stringBuilder.ToString();
        }
    }
}
