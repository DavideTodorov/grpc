﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Car.Parking.System.Models
{
    public class Part
    {
        public Part(string PartName)
        {
            this.PartName = PartName;
            this.cars = new List<CarModel>();
        }

        [Key]
        public int Id { get; set; }

        public string PartName { get; set; }

        public List<CarModel> cars { get; set; }

        public override string ToString()
        {
            StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.AppendLine($"Id: {Id}");
            stringBuilder.AppendLine($"Name: {PartName}");    

            return stringBuilder.ToString();
        }
    }
}
